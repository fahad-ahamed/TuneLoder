export function createBot(deps) {
  /** chatId → session */
  const sessions = new Map();
  const getSession = (chatId) => {
    if (!sessions.has(chatId)) {
      sessions.set(chatId, {
        quality: 320,        // default quality (sticky, chosen via buttons)
        picker: null,        // { tracks, selected:Set, page }
        pendingVideo: null,  // { track } awaiting quality choice
        queue: [],           // [{ track, quality }]
        active: null,        // { track, quality } the job currently downloading
        lastFailed: [],      // [{ track, quality }] for the Retry button
        cancelRequested: false,
        cancelWasUser: false,
        editAt: 0,           // last live-edit timestamp
      });
    }
    return sessions.get(chatId);
  };

  const send = (chatId, text, extra) =>
    deps.tgCall("sendMessage", { chat_id: chatId, text, ...extra }).catch((e) =>
      deps.log(`sendMessage: ${e.message}`)
    );

  const editMsg = async (chatId, messageId, text, markup) => {
    try {
      await deps.tgCall("editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text,
        ...(markup ? { reply_markup: markup } : {}),
      });
    } catch (e) {
      const m = String(e.message);
      if (!/message is not modified|MESSAGE_ID_INVALID|message to edit not found/i.test(m)) {
        deps.log(`editMessageText: ${m.slice(0, 120)}`);
      }
    }
  };

  const answerCb = (id) =>
    deps.tgCall("answerCallbackQuery", { callback_query_id: id }).catch(() => {});

  /* ---------------- keyboards ---------------- */

  const qualityRows = (sess) => [
    QUALITIES.map((q) => B(`${sess.quality === q ? "✓ " : ""}${q} kbps`, `q:${q}`)),
    [B("✖ Cancel", "cx")],
  ];

  const pickerRows = (sess) => {
    const p = sess.picker;
    const n = p.tracks.length;
    const pages = Math.max(1, Math.ceil(n / PAGE_SIZE));
    const from = p.page * PAGE_SIZE;
    const rows = [];

    // track number buttons (selected → ✓n), 5 per row
    for (let r = 0; r < Math.ceil(Math.min(PAGE_SIZE, n - from) / 5); r++) {
      rows.push(
        Array.from({ length: 5 }, (_, c) => {
          const idx = from + r * 5 + c;
          if (idx >= n) return null;
          const sel = p.selected.has(idx);
          return B(sel ? `✓${idx + 1}` : `${idx + 1}`, `t:${idx}`);
        })
      );
    }

    rows.push([B(`All ${n}`, "all"), B("✓ This page", "pgall")]);
    if (pages > 1) {
      rows.push([
        p.page > 0 ? B("◀ Prev", `p:${p.page - 1}`) : null,
        B(`${p.page + 1}/${pages}`, "noop"),
        p.page + 1 < pages ? B("Next ▶", `p:${p.page + 1}`) : null,
      ]);
    }
    const count = p.selected.size || n;
    rows.push([B(`⬇ Download ${count}`, "go")]);
    rows.push([B(`🎚 ${sess.quality} kbps`, "qual"), B("✖ Cancel", "cx")]);
    return rows;
  };

  const pickerText = (sess) => {
    const p = sess.picker;
    const total = p.tracks.length;
    const showing = p.tracks.slice(p.page * PAGE_SIZE, p.page * PAGE_SIZE + PAGE_SIZE);
    const lines = showing.map((t, i) => {
      const idx = p.page * PAGE_SIZE + i;
      const mark = p.selected.has(idx) ? "✓ " : "";
      const dur = t.duration ? ` · ${t.duration}` : "";
      return `${mark}${idx + 1}. ${String(t.title).slice(0, 48)}${dur}`;
    });
    return [
      `📋 ${p.title}`,
      `👤 ${p.author} · ${total} tracks${p.selected.size ? ` · ${p.selected.size} selected` : ""}`,
      "",
      ...lines,
      "",
      "Tap numbers to pick · All for everything · then ⬇ Download",
    ].join("\n");
  };

  /* ---------------- queue panel (the /cancel view) ---------------- */

  const queuePanel = (sess) => {
    const current = sess.active ? sess.active.track : null;
    const items = sess.queue;
    const lines = [];
    if (current) lines.push(`▶ now: ${current.title.slice(0, 55)}`);
    items.forEach((it, i) => lines.push(`${i + 1}. ${it.track.title.slice(0, 55)}`));
    const text = items.length || current
      ? `Queue (${items.length + (current ? 1 : 0)}):\n\n${lines.join("\n").slice(0, 3500)}`
      : "Queue is empty — send a YouTube link.";
    const rows = items.slice(0, 30).map((it, i) => [B(`✖ #${i + 1}`, `rm:${i}`)]);
    if (current || items.length > 1) rows.push([B("🛑 Cancel everything", "cancel")]);
    return { text, markup: kb(rows) };
  };

  /* ---------------- queue + runner ---------------- */

  function enqueue(sess, jobs) {
    sess.queue.push(...jobs);
  }

  function pump(chatId) {
    const sess = getSession(chatId);
    if (sess.active) return undefined; // already draining
    return runQueue(chatId, sess);
  }

  async function runQueue(chatId, sess) {
    // ONE status message reused for the whole queue run
    let statusMsgId = null;
    let done = 0;
    const failed = [];

    try {
      while (sess.queue.length > 0) {
        if (sess.cancelRequested) break;
        const job = sess.queue.shift();
        const total = done + 1 + sess.queue.length;
        sess.active = { track: job.track, quality: job.quality };
        sess.editAt = 0;

        const label = `#${done + 1}/${total}`;
        const text = `⬇ ${label} · ${job.track.title.slice(0, 60)}\n🎚 ${job.quality}kbps · starting…`;
        if (!statusMsgId) {
          const m = await deps
            .tgCall("sendMessage", {
              chat_id: chatId,
              text,
              reply_markup: kb([[B("🛑 Cancel all", "cancel")]]),
            })
            .catch(() => null);
          statusMsgId = m?.message_id ?? null;
        } else {
          await editMsg(chatId, statusMsgId, text, kb([[B("🛑 Cancel all", "cancel")]]));
        }

        const res = await downloadTrack(chatId, sess, job, statusMsgId, { done, total });
        if (res === "ok") done++;
        else if (res === "cancelled") break;
        else failed.push({ track: job.track, quality: job.quality, error: res });
      }
    } finally {
      sess.active = null;
    }

    // summary
    const skipped = sess.queue.splice(0);
    sess.cancelRequested = false;

    if (sess.cancelWasUser) {
      sess.cancelWasUser = false;
      let summary = `✖ Cancelled — ${done} sent, ${failed.length + skipped.length} skipped.`;
      if (skipped.length) {
        summary += `\n\nSkipped:\n${skipped.map((j) => `• ${j.track.title.slice(0, 60)}`).join("\n").slice(0, 3000)}`;
      }
      if (statusMsgId) await editMsg(chatId, statusMsgId, summary);
      else await send(chatId, summary);
      return;
    }

    if (failed.length) {
      sess.lastFailed = failed;
      const errLines = failed
        .slice(0, 8)
        .map((f) => `• ${f.track.title.slice(0, 40)} — ${String(f.error).slice(0, 80)}`)
        .join("\n");
      const text = `⚠️ ${done}/${done + failed.length + skipped.length} sent — ${failed.length} failed:\n${errLines}${failed.length > 8 ? `\n… +${failed.length - 8} more` : ""}`;
      const markup = kb([[B(`🔁 Retry ${failed.length} failed`, "retry")]]);
      if (statusMsgId) await editMsg(chatId, statusMsgId, text, markup);
      else await send(chatId, text, { reply_markup: markup });
    } else if (statusMsgId) {
      await editMsg(chatId, statusMsgId, `✅ All done — ${done}/${done} sent · server copies auto-deleted.`);
    } else if (done > 0) {
      await send(chatId, `✅ All done — ${done} sent`);
    }
  }

  /**
   * Download one track with live progress on the shared status message.
   * Returns "ok" | "cancelled" | error-string.
   */
  async function downloadTrack(chatId, sess, job, statusMsgId, ctx) {
    const key = `${job.track.videoId}:${job.quality}`;
    const posLabel = `#${ctx.done + 1}/${ctx.total}`;
    const title = job.track.title.slice(0, 60);

    const renderStatus = (pct, speed, eta, phase) => {
      const line =
        pct != null
          ? `${bar(pct)} ${Math.round(pct)}%${speed ? ` · ${speed}` : ""}${eta ? ` · ETA ${eta}` : ""}`
          : phase === "encoding"
            ? "🎧 encoding MP3…"
            : "🔄 starting…";
      return `⬇ ${posLabel} · ${title}\n🎚 ${job.quality}kbps\n${line}`;
    };

    // live progress loop while fetch-audio is in flight
    const poller = (async () => {
      const myVideo = job.track.videoId;
      for (;;) {
        await sleep(PROGRESS_POLL_MS);
        const act = sess.active;
        if (!act || act.track.videoId !== myVideo) return;
        if (Date.now() - sess.editAt < EDIT_MIN_MS) continue;
        try {
          const r = await deps.api(`/api/progress?key=${encodeURIComponent(key)}`);
          const j = r?.data;
          if (!j || j.phase === "idle") continue;
          if (statusMsgId) {
            sess.editAt = Date.now();
            await editMsg(chatId, statusMsgId, renderStatus(j.pct, j.speed, j.eta, j.phase));
          }
        } catch { /* noop */ }
      }
    })();

    try {
      const res = await deps.api("/api/fetch-audio", {
        videoId: job.track.videoId,
        bitrate: job.quality,
        title: job.track.title,
        author: job.track.author,
      });
      if (!res.ok) {
        if (res.data?.cancelled || /cancel/i.test(String(res.data?.error))) return "cancelled";
        throw new Error(res.data?.hint || res.data?.error || `HTTP ${res.status}`);
      }
      const { path: file, filename, bitrate } = res.data;
      try {
        if (statusMsgId) {
          sess.editAt = Date.now();
          await editMsg(chatId, statusMsgId, `📤 ${posLabel} · ${title}\n📤 sending to Telegram…`);
        }
        const partsSent = await sendMaybeChunked(chatId, file, {
          filename,
          title: job.track.title,
          author: job.track.author,
          bitrate,
        });
        if (partsSent > 1 && statusMsgId) {
          await editMsg(chatId, statusMsgId, `✅ ${posLabel} · ${title} — sent in ${partsSent} parts`);
        }
        return "ok";
      } finally {
        deps.removeFile(file); // auto-clean: server copy deleted right after send
      }
    } catch (e) {
      return String(e.message).slice(0, 160);
    } finally {
      sess.active = null; // stops the poller on its next tick
    }
  }

  async function sendMaybeChunked(chatId, file, meta) {
    const size = fs.statSync(file).size;
    if (size <= PART_LIMIT) {
      await deps.sendAudio(chatId, file, meta);
      return 1;
    }
    // big track → probe duration, split, send parts
    const duration = await probeDuration(file);
    const { dir, parts } = await splitIntoParts(file, size, duration);
    deps.log(`chunking ${(size / 1048576).toFixed(1)}MB → ${parts.length} parts (dur ${Math.round(duration)}s)`);
    try {
      for (let i = 0; i < parts.length; i++) {
        const base = meta.filename.replace(/\.mp3$/, "");
        await deps.sendAudio(chatId, parts[i], {
          ...meta,
          filename: `${base} part${i + 1}-${parts.length}.mp3`,
          part: `part ${i + 1}/${parts.length} of ${Math.round(size / 1048576)}MB`,
        });
      }
      return parts.length;
    } finally {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* noop */ }
    }
  }

  /* ---------------- link intake ---------------- */

  async function handleLink(chatId, url) {
    const sess = getSession(chatId);
    const info = await deps.api("/api/info", { url });
    if (!info.ok) throw new Error(info.data?.error || "Could not read that link");
    const d = info.data;

    if (d.type === "video") {
      const t = d.track;
      const busy = !!(sess.active || sess.queue.length);
      sess.pendingVideo = { track: t };
      const note = busy
        ? "\n\n(downloads are running — this one joins the queue)"
        : "";
      await send(
        chatId,
        `🎵 ${t.title}\n👤 ${t.author}${t.duration ? `\n⏱ ${t.duration}` : ""}${note}\n\nTap a quality to download:`,
        { reply_markup: kb(qualityRows(sess)) }
      );
      return;
    }

    // playlist → interactive picker
    const tracks = d.tracks ?? [];
    if (!tracks.length) throw new Error("Playlist came back empty — try a different link");
    sess.picker = {
      tracks,
      title: d.title,
      author: d.author,
      selected: new Set(),
      page: 0,
    };
    await send(chatId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
  }

  /* ---------------- callback routing ---------------- */

  async function handleCallback(chatId, data, messageId, cbId) {
    const sess = getSession(chatId);

    // global: kill the active download + clear the whole queue
    if (data === "cancel") {
      sess.cancelRequested = true;
      sess.cancelWasUser = true;
      if (sess.active?.track) {
        await deps
          .api("/api/cancel", { videoId: sess.active.track.videoId, bitrate: sess.active.quality })
          .catch(() => {});
      }
      await answerCb(cbId);
      return;
    }

    if (data === "retry") {
      const failed = sess.lastFailed.splice(0);
      if (!failed.length) return answerCb(cbId);
      enqueue(sess, failed.map((f) => ({ track: f.track, quality: f.quality })));
      await answerCb(cbId);
      await send(chatId, `🔁 Retrying ${failed.length} track${failed.length > 1 ? "s" : ""}…`);
      pump(chatId);
      return;
    }

    // remove one queue item (from the /cancel queue panel)
    if (data.startsWith("rm:")) {
      const idx = Number(data.slice(3));
      const removed = sess.queue.splice(idx, 1)[0];
      await answerCb(cbId);
      const panel = queuePanel(sess);
      await editMsg(chatId, messageId, `Removed: ${removed ? removed.track.title.slice(0, 50) : "—"}\n\n${panel.text}`, panel.markup);
      return;
    }

    if (data === "cx") {
      sess.picker = null;
      sess.pendingVideo = null;
      await answerCb(cbId);
      await editMsg(chatId, messageId, "✖ Cancelled. Send a new link anytime.");
      return;
    }

    if (data === "noop") return answerCb(cbId);

    // quality taps (work for pending video AND for the open picker)
    if (data.startsWith("q:")) {
      const q = Number(data.slice(2));
      if (!QUALITIES.includes(q)) return answerCb(cbId);
      sess.quality = q;

      if (sess.picker) {
        await answerCb(cbId);
        await editMsg(chatId, messageId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
        return;
      }
      const pv = sess.pendingVideo;
      sess.pendingVideo = null;
      await answerCb(cbId);
      if (pv) {
        enqueue(sess, [{ track: pv.track, quality: q }]);
        pump(chatId);
      } else {
        await send(chatId, `🎚 Default quality set: ${q}kbps`);
      }
      return;
    }

    // picker actions
    if (sess.picker) {
      const p = sess.picker;
      if (data.startsWith("t:")) {
        const idx = Number(data.slice(2));
        if (p.selected.has(idx)) p.selected.delete(idx);
        else p.selected.add(idx);
        await answerCb(cbId);
        await editMsg(chatId, messageId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
        return;
      }
      if (data === "all") {
        p.selected = new Set(p.tracks.map((_, i) => i));
        await answerCb(cbId);
        await editMsg(chatId, messageId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
        return;
      }
      if (data === "pgall") {
        const from = p.page * PAGE_SIZE;
        const to = Math.min(p.tracks.length, from + PAGE_SIZE);
        for (let i = from; i < to; i++) p.selected.add(i);
        await answerCb(cbId);
        await editMsg(chatId, messageId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
        return;
      }
      if (data.startsWith("p:")) {
        p.page = Math.max(0, Number(data.slice(2)) || 0);
        await answerCb(cbId);
        await editMsg(chatId, messageId, pickerText(sess), { reply_markup: kb(pickerRows(sess)) });
        return;
      }
      if (data === "qual") {
        await answerCb(cbId);
        await editMsg(chatId, messageId,
          `🎚 Pick quality for this playlist — current: ${sess.quality}kbps`,
          { reply_markup: kb(qualityRows(sess)) });
        return;
      }
      if (data === "go") {
        const sel = p.selected.size ? [...p.selected].sort((a, b) => a - b) : p.tracks.map((_, i) => i);
        const jobs = sel.map((i) => ({ track: p.tracks[i], quality: sess.quality }));
        sess.picker = null;
        await answerCb(cbId);
        await editMsg(chatId, messageId, `📦 ${sel.length} track${sel.length > 1 ? "s" : ""} · ${sess.quality}kbps — starting queue…`);
        enqueue(sess, jobs);
        pump(chatId);
        return;
      }
    }

    await answerCb(cbId);
  }

  /* ---------------- text / commands ---------------- */

  async function handleText(chatId, rawText) {
    const text = String(rawText ?? "").trim();
    const sess = getSession(chatId);

    if (/^\/start/.test(text)) {
      return send(chatId, `👋 TuneLoad bot — buttons only, zero typing.\n\n${HELP}`);
    }
    if (/^\/help/.test(text)) {
      return send(chatId, HELP);
    }

    if (/^\/cancel/.test(text)) {
      const panel = queuePanel(sess);
      return send(chatId, panel.text, { reply_markup: panel.markup });
    }

    if (/^\/status/.test(text)) {
      const r = await deps.api("/api/status");
      const d = r.data ?? {};
      const q = d.queue ?? {};
      return send(
        chatId,
        `Engine: yt-dlp ${d.ytdlp ? "✅" : "❌"} · ffmpeg ${d.ffmpeg ? "✅" : "❌"} · cookie sets ${d.cookieSets ?? "—"}\nQueue: ${q.running ?? 0} running · ${q.waiting ?? 0} waiting\nDefault quality: ${sess.quality}kbps`
      );
    }

    if (/^\/quality/.test(text)) {
      return send(chatId, "Tap a quality (also available on every link):", {
        reply_markup: kb([QUALITIES.map((x) => B(`${x} kbps`, `q:${x}`))]),
      });
    }

    const link = findYouTubeLink(text);
    if (link) {
      try {
        await handleLink(chatId, link);
      } catch (e) {
        await send(chatId, `⚠️ ${String(e.message).slice(0, 300)}`);
      }
      return;
    }

    return send(chatId, "Send me a YouTube link (video or playlist) — everything else is buttons.");
  }

  return { handleText, handleCallback, sessions };
}
