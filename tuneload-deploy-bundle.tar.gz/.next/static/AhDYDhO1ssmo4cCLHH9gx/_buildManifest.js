self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/0n9b73aflhrui.js"
  ],
  "/_error": [
    "static/chunks/413b9y5fyx4oe.js"
  ],
  "/admin": [
    "static/chunks/1frd41eg65y4j.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin"
  ]
};self.__TURBOPACK_PAGE_BOOTSTRAP = {"/admin":{"otherChunks":["static/chunks/3hvm33uwkztcy.js","static/chunks/0s9mzsfrrx7k6.js"],"runtimeModuleIds":[10783,66180]},"/":{"otherChunks":["static/chunks/10qyuuvthorif.js","static/chunks/0s9mzsfrrx7k6.js"],"runtimeModuleIds":[10783,55075]},"/_app":{"otherChunks":["static/chunks/44k9vwvznwhzk.js","static/chunks/3rync34vg26ra.js","static/chunks/3hvfi-bckxzcd.js","static/chunks/0mr1ugbug6qju.css"],"runtimeModuleIds":[10783,94757]},"/_error":{"otherChunks":["static/chunks/3n_c8q1xtyv-r.js"],"runtimeModuleIds":[10783,80184]}};self.__TURBOPACK_CHUNK_LOADING_GLOBAL = "TURBOPACK";self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()