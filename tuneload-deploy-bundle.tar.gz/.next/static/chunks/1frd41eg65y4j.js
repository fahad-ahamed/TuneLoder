__turbopack_load_page_chunks__("/admin", [
  "static/chunks/3hvm33uwkztcy.js",
  "static/chunks/0s9mzsfrrx7k6.js",
  "static/chunks/turbopack-077hmtqrhcoji.js"
])
