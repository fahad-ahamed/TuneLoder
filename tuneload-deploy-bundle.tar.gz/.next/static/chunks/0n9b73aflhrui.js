__turbopack_load_page_chunks__("/", [
  "static/chunks/10qyuuvthorif.js",
  "static/chunks/0s9mzsfrrx7k6.js",
  "static/chunks/turbopack-077hmtqrhcoji.js"
])
