__turbopack_load_page_chunks__("/_error", [
  "static/chunks/3n_c8q1xtyv-r.js",
  "static/chunks/turbopack-077hmtqrhcoji.js"
])
