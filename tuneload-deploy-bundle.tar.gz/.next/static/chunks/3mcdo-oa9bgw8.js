__turbopack_load_page_chunks__("/_app", [
  "static/chunks/44k9vwvznwhzk.js",
  "static/chunks/3rync34vg26ra.js",
  "static/chunks/3hvfi-bckxzcd.js",
  "static/chunks/0mr1ugbug6qju.css",
  "static/chunks/turbopack-077hmtqrhcoji.js"
])
