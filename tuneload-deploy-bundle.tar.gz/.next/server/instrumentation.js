var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_0z1zbarr6p1z3._.js")
R.m(23322)
module.exports=R.m(23322).exports
