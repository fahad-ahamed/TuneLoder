var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__1wct7dlblml6-._.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/_1-sac-oip3d1t._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_07yss3khe0dh5.js")
R.m(28101)
module.exports=R.m(28101).exports
