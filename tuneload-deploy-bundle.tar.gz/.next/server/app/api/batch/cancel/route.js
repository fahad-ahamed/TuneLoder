var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/batch/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__00xt78gr3kipj._.js")
R.c("server/chunks/_0e5xc4fmx4sgq._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_api_batch_cancel_route_actions_0y4vl2t6ul4wp.js")
R.m(4136)
module.exports=R.m(4136).exports
