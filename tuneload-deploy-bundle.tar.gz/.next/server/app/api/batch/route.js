var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/batch/route.js")
R.c("server/chunks/[root-of-the-server]__00xt78gr3kipj._.js")
R.c("server/chunks/_0b95yktyxgbh4._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_api_batch_route_actions_1i4arzjzwlfai.js")
R.m(93254)
module.exports=R.m(93254).exports
