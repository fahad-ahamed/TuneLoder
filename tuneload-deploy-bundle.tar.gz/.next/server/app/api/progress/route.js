var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/progress/route.js")
R.c("server/chunks/[root-of-the-server]__10u-bmadpzzjg._.js")
R.c("server/chunks/_06_k3ynfzqnqb._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_api_progress_route_actions_1suagj4jmid3z.js")
R.m(60827)
module.exports=R.m(60827).exports
