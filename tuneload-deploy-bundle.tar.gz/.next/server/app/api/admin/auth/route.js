var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/route.js")
R.c("server/chunks/[externals]__06yiwj961z_31._.js")
R.c("server/chunks/src_lib_ytd_admin_ts_1lu_-_q6d324o._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_01d0gbc678uzf._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_route_actions_1bj3gxa71kin0.js")
R.m(72669)
module.exports=R.m(72669).exports
