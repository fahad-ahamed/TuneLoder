var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fetch-audio/route.js")
R.c("server/chunks/src_lib_ytd_cleanup_ts_1rd07ini_m9oc._.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_1d0zlkmpf0z25._.js")
R.c("server/chunks/_next-internal_server_app_api_fetch-audio_route_actions_17z3sj1gvr_s5.js")
R.m(57158)
module.exports=R.m(57158).exports
