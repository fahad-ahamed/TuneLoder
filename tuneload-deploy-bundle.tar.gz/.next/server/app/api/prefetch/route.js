var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prefetch/route.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/_1-zb2yh_gr_e-._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/_next-internal_server_app_api_prefetch_route_actions_1qrth49x1o0ds.js")
R.m(27292)
module.exports=R.m(27292).exports
