var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download-file/route.js")
R.c("server/chunks/[root-of-the-server]__1wct7dlblml6-._.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/_1pbthnvgsi8_n._.js")
R.c("server/chunks/_next-internal_server_app_api_download-file_route_actions_0hqfrry1dk36w.js")
R.m(60364)
module.exports=R.m(60364).exports
