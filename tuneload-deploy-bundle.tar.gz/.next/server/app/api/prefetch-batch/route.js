var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prefetch-batch/route.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/_0mocq7zcl1t7y._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/_next-internal_server_app_api_prefetch-batch_route_actions_0hqh65_oi4r4q.js")
R.m(84965)
module.exports=R.m(84965).exports
