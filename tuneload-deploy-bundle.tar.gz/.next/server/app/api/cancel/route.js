var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__0f-inmk65ygdl._.js")
R.c("server/chunks/_0j22dsuki1-2-._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/[root-of-the-server]__04khqszi5jpq1._.js")
R.c("server/chunks/_next-internal_server_app_api_cancel_route_actions_01oitta01izs9.js")
R.m(70997)
module.exports=R.m(70997).exports
