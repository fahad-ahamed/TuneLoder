var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram/route.js")
R.c("server/chunks/[externals]__04djaccv84z_v._.js")
R.c("server/chunks/src_lib_ytd_admin_ts_1lu_-_q6d324o._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0wv9rn52ci6yv._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram_route_actions_0scaovl3ni3g4.js")
R.m(1595)
module.exports=R.m(1595).exports
