var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[externals]__0k2m0f4kk2of0._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1ju8i8j1lfntn._.js")
R.m(17359)
module.exports=R.m(17359).exports
