globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/10qyuuvthorif.js",
      "static/chunks/0s9mzsfrrx7k6.js",
      "static/chunks/turbopack-077hmtqrhcoji.js"
    ],
    "/_app": [
      "static/chunks/44k9vwvznwhzk.js",
      "static/chunks/3rync34vg26ra.js",
      "static/chunks/3hvfi-bckxzcd.js",
      "static/chunks/0mr1ugbug6qju.css",
      "static/chunks/turbopack-077hmtqrhcoji.js"
    ],
    "/_error": [
      "static/chunks/3n_c8q1xtyv-r.js",
      "static/chunks/turbopack-077hmtqrhcoji.js"
    ],
    "/admin": [
      "static/chunks/3hvm33uwkztcy.js",
      "static/chunks/0s9mzsfrrx7k6.js",
      "static/chunks/turbopack-077hmtqrhcoji.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/AhDYDhO1ssmo4cCLHH9gx/_buildManifest.js",
    "static/AhDYDhO1ssmo4cCLHH9gx/_ssgManifest.js",
    "static/AhDYDhO1ssmo4cCLHH9gx/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0j1we3cwg31qe.js",
    "static/chunks/0m3mby5pxg4oz.js",
    "static/chunks/0ohb6jwfe1-fr.js",
    "static/chunks/turbopack-077hmtqrhcoji.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/admin": {
      "otherChunks": [
        "static/chunks/3hvm33uwkztcy.js",
        "static/chunks/0s9mzsfrrx7k6.js"
      ],
      "runtimeModuleIds": [
        10783,
        66180
      ]
    },
    "/": {
      "otherChunks": [
        "static/chunks/10qyuuvthorif.js",
        "static/chunks/0s9mzsfrrx7k6.js"
      ],
      "runtimeModuleIds": [
        10783,
        55075
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/0m3mby5pxg4oz.js",
        "static/chunks/0ohb6jwfe1-fr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/0m3mby5pxg4oz.js",
        "static/chunks/0ohb6jwfe1-fr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_app": {
      "otherChunks": [
        "static/chunks/44k9vwvznwhzk.js",
        "static/chunks/3rync34vg26ra.js",
        "static/chunks/3hvfi-bckxzcd.js",
        "static/chunks/0mr1ugbug6qju.css"
      ],
      "runtimeModuleIds": [
        10783,
        94757
      ]
    },
    "/_error": {
      "otherChunks": [
        "static/chunks/3n_c8q1xtyv-r.js"
      ],
      "runtimeModuleIds": [
        10783,
        80184
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
