module.exports=[97619,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cancel_route_actions_01oitta01izs9.js.map