module.exports=[15750,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_batch_cancel_route_actions_0y4vl2t6ul4wp.js.map