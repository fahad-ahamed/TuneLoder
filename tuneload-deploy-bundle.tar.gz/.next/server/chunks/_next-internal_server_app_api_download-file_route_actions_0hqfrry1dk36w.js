module.exports=[17448,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_download-file_route_actions_0hqfrry1dk36w.js.map