module.exports=[87504,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_prefetch_route_actions_1qrth49x1o0ds.js.map