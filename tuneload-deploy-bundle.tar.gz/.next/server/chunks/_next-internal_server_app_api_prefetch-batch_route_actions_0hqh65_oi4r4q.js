module.exports=[27217,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_prefetch-batch_route_actions_0hqh65_oi4r4q.js.map