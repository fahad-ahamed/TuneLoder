module.exports=[80850,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cookies_verify_route_actions_0aompebak7rw0.js.map