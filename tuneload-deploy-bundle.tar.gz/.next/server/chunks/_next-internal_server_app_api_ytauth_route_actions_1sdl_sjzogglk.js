module.exports=[79828,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ytauth_route_actions_1sdl_sjzogglk.js.map