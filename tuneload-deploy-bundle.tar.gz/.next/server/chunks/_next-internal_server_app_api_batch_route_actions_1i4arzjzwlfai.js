module.exports=[82745,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_batch_route_actions_1i4arzjzwlfai.js.map