module.exports=[70406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},14747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))},8171,(a,b,c)=>{b.exports=a.x("react/jsx-runtime",()=>require("react/jsx-runtime"))}];

//# sourceMappingURL=%5Bexternals%5D__0k2m0f4kk2of0._.js.map